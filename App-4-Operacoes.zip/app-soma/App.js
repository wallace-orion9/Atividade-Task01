import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');

  function soma() {
    const rsoma = parseFloat(num1) + parseFloat(num2);
    alert('O resultado da soma é: ' + rsoma);
  }
  function subtracao() {
    const rsub = parseFloat(num1) - parseFloat(num2);
    alert('O resultado da subtração é: ' + rsub);
  }
  function divisao() {
    const rdiv = parseFloat(num1) / parseFloat(num2);
    alert('O resultado da divisão é: ' + rdiv);
  }
  function multiplicacao() {
    const rmult = parseFloat(num1) * parseFloat(num2);
    alert('O resultado da multiplicação é: ' + rmult);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}> Soma de Valores </Text>
      <TextInput
        style={styles.input1}
        keyboardType="numeric"
        placeholder="Digite um número"
        onChangeText={(num1) => setNum1(num1)}
      />
      <TextInput
        style={styles.input1}
        keyboardType="numeric"
        placeholder="Digite um número"
        onChangeText={(num2) => setNum2(num2)}
      />
      <TouchableOpacity style={styles.btn} onPress={soma}>
        <Text style={styles.titulobtn}> Soma </Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={subtracao}>
        <Text style={styles.titulobtn}> Subtração </Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={divisao}>
        <Text style={styles.titulobtn}> Divisão </Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={multiplicacao}>
        <Text style={styles.titulobtn}> Multiplicação </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#59cae3',
    padding: 8,
  },
  titulo: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#ff0000',
    borderRadius: 15,
    margin: 30,
    padding: 10,
  },
  input1: {
    backgroundColor: '#999999',
    margin: 15,
    borderRadius: 15,
    padding: 10,
  },
  btn: {
    alignItems: 'center',
    backgroundColor: '#ffaa33',
    margin: 5,
    borderRadius: 10,
  },
  titulobtn: {
    fontSize: 25,
    color: '#fff',
  },
});

import * as React from 'react';
import { Text, View, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function Home(props) {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>As melhores Receitas de Bolo </Text>
      <Image source={require('../assets/principal-bolo.jpg')} />

      <TouchableOpacity onPress={()=>{props.navigation.navigate('BoloChocolate')}}>
        <Text> Bolo de Chocolate </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={()=>{props.navigation.navigate('BoloFuba')}}>
        <Text> Bolo de Fubá </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={()=>{props.navigation.navigate('BoloMilho')}}>
        <Text> Bolo de Milho </Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 8,
    alignItems:'center',
    marginTop: 20
  },
  titulo: {
    fontSize: 40,
    marginTop: 10,
    textAlign: 'center'
  },
  img: {
    borderRadius:10,
    width: 300,
    height: 200, 
    resizeMode: 'center'
  }, 
});
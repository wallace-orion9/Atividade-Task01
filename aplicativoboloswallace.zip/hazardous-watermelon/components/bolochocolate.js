import * as React from 'react';
import { Text, View, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function Bolochocolate() {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Bolo de chocolate</Text>
      <Image style={styles.img} source={require('../assets/bolo-chocolate.jpg')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#733100',
    padding: 8,
    alignItems:'center',
    marginTop: 20
  },
  titulo: {
    fontSize: 40,
    marginTop: 10,
    textAlign: 'center'
  },
  img: {
    borderRadius:10,
    width: 300,
    height: 200, 
    resizeMode: 'center'
  }, 
});
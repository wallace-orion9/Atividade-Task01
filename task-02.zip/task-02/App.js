import React,{useState}from 'react';
import { Text, View, StyleSheet, FlatList, Image} from 'react-native';
import AppLoading from 'expo-app-loading';
import {useFonts, Inter_900Black, Allan_400Regular,Oswald_300Light, Bangers_400Regular, Jost_600SemiBold_Italic} from '@expo-google-fonts/dev';

export default function App() {

let [fontsLoaded] =useFonts({
Inter_900Black,
Allan_400Regular,
Oswald_300Light, 
Bangers_400Regular,
Jost_600SemiBold_Italic
});

if(!fontsLoaded){
  return <AppLoading/>;
}else{
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
      5 Jogadores que eu (Wallace) sou fã
      {'\n'}{'\n'}
      </Text>
      <FlatList //Laço de repetição - loop
        data={arrayConsole}
        renderItem={({item})=>(
      <View>
        <Text style={console}>
         {'\n'}
        <Text style={styles.subtitulo2}>{item.titulo}</Text>
        {'\n'}
        {'\n'}
        <Text style={styles.subtitulo}> Lançamento:</Text>
        <Text style={styles.informacoes}>{item.lancamento}</Text> 
        {'\n'} 
        <Text style={styles.subtitulo}> Descrição:</Text>
        <Text style={styles.informacoes}>{item.descricao}</Text>
        {'\n'}
        {'\n'}
        </Text>
        <Image style={styles.img} source={item.capa}/>
      </View>
      )}
      />
    </View>
  );
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#696969',
    padding: 8,
    alignItems:'center',
    marginTop: 20
  },
  titulo: {
    fontSize: 40,
    fontFamily:'Jost_600SemiBold_Italic',
    marginTop: 10,
    textAlign: 'center'
  },
  img: {
    borderRadius:10,
    width: 300,
    height: 200, 
    resizeMode: 'center'
  }, 
  subtitulo:{
    fontSize: 20,
    color: '#66a7fe',
    fontWeight: 100,
    fontFamily: 'Allan_400Regular'
  },
  informacoes:{
        fontSize: 15,
    fontWeight: 100,
    fontFamily: 'Oswald_300Light'
  },
  subtitulo2:{
    fontSize: 30,
    color: 'black',
    fontWeight: 100,
    fontFamily: 'Bangers_400Regular',
    textAlign: 'center',
  }
});

const arrayConsole =[
  {titulo:'Cristiano Ronaldo',gols:'832', descricao:'Cristiano Ronaldo dos Santos Aveiro é um futebolista português que atua como extremo-esquerdo ou ponta de lança. Atualmente joga pelo Al-Nassr, da Arábia Saudita e pela Seleção Portuguesa, onde é capitão.',
capa:require('./assets/robo.jpg')},
  {titulo:'Neymar Júnior', gols:'436', descricao:'Neymar da Silva Santos Júnior é um futebolista brasileiro que atua como atacante. Atualmente joga pelo Paris Saint-Germain e pela Seleção Brasileira. É considerado o principal futebolista brasileiro da atualidade e um dos melhores futebolistas do mundo.',
  capa:require('./assets/neymar1.jpg')}, 
  {titulo:'Thomas Muller', gols:'269 ', descricao: 'Thomas Müller é um futebolista alemão que atua como meia ou atacante. Atualmente joga no Bayern de Munique. Considerado um dos grandes nomes da história do futebol alemão, é o terceiro jogador em atividade com mais gols em Copas do Mundo FIFA, com 10 gols, atrás de Kylian Mbappé e Lionel Messi.',
capa:require('./assets/muller.jpg')},
  {titulo:'Kylian Mbappé', gols:'266', descricao:'Kylian Sanmi Mbappé Lottin é um futebolista francês que atua como atacante. Atualmente joga pelo Paris Saint-Germain e pela Seleção Francesa. Considerado um dos melhores jogadores da última década, ele é conhecido pelo seus dribles e sua velocidade explosiva.  ',
capa:require('./assets/kylian.jpg')},
  {titulo:'Vinícius Júnior',gols:'74', descricao:'Vinícius José Paixão de Oliveira Júnior, mais conhecido como Vinícius Júnior ou Vini Jr, é um futebolista brasileiro que atua como ponta-esquerda. Atualmente joga no Real Madrid e pela Seleção Brasileira.',capa:require('./assets/vini.jpg')}
];
